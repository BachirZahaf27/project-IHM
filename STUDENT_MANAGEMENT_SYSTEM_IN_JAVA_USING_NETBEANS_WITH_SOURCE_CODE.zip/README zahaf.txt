
-------------------------------------------------------------README------------------------------------------------------------------------
donc j'ai trouvé cette solution mais je ne peux pas la modifier en ceci (changez l'élément en français et ajoutez mon élément plutôt que l'élément de modèle)
vous pouvez télécharger la solution ici
également lorsque vous exécutez le projet, comparez-le à ces photos pour comprendre,
my element:
---------------------login.java-------------------------------
user name ==>Administrateur
password ==> mot pass
---------------------mainmenu.java----------------------------
add a studant==> ajouter un étudiant 
-------------------StudentInformation.java---------------------
family name==> nom
name==>prenom
date of birth==> date de Naissance
sector==>fillère (20 items) //makanch basah dirha 
faculty== la faculté (9 items)//makanch basah dirha 
year of study.==>année d'étude (example:2020-2021)//makanch basah dirha 
------------------------------------------------------------------
------------------------------------------------------------------
!!fel li photo rani dayarlk chakano w charani baghihom ykono!!
-------------------------------------------------------------------

hope that will clear everything 🙏🙏🙏

-----------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------





---------------------------------------------------Projet IHM ----------------------------------------------------------------------------
  Concevoir et développez en java, une application pour la création d’une carte d’étudiant de l’université Abdelhamid ibn badis. 
Tout d’abord l’utilisateur (Administrateur) doit saisir les informations  concernant un étudiant dans un formulaire,
- les informations à saisir sont : (Le nom, le prénom, la Date de naissance, la filière,  la faculté et l’année d’étude).

- Un numéro d’étudiant doit être attribué automatiquement par le système et figuré sur la carte d’étudiant. 
- Toutes  ses informations sont obligatoires.  

-Une photo d’identité de chaque étudiant doit être ajoutée au formulaire. 

-Sur le formulaire le logo de l’université doit paraitre.  //umbu logo.png

-Une fois toute les informations saisi, l’administrateur valide sa saisie, après validation une carte d’étudiant contenant toutes les informations sur l’étudiant ainsi que sa photo et le logo de l’université est créer.  

-L’administrateur doit avoir la possibilité d’enregistré la carte ou de l’imprimé, de modifier une saisie dans le cas d’une erreur. 

-Il doit avoir la possibilité de créer une autre carte, sans avoir a fermé l’interface. 

-Le  formulaire  de saisi ainsi que la carte d’étudiant doivent avoir une interface ergonomique  respectant les règles de conception d’une ihm(robustesse , guidage , cohérence …...). 
 
Règles concernant le projet :  
- Le projet peut être fait en binôme ou en monôme. Aucun groupe de trinôme ne sera accepté.   
 - Le projet doit être rendu et consulté le Lundi 13 février, un programme et une salle  pour la consultation vous sera affichée ultérieurement. 
--------------------------------------------------------------------------------------------------------------------------------------------------------